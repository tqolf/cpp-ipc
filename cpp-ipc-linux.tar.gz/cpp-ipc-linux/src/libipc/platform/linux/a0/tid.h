#ifndef A0_TID_H
#define A0_TID_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t a0_tid();

#ifdef __cplusplus
}
#endif

#endif  // A0_TID_H
