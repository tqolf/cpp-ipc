#ifndef A0_UNUSED_H
#define A0_UNUSED_H

#define A0_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#define A0_MAYBE_UNUSED(X) ((void)(X))

#endif  // A0_UNUSED_H
