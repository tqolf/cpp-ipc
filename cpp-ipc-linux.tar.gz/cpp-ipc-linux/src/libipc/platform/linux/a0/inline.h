#ifndef A0_INLINE_H
#define A0_INLINE_H

#define A0_STATIC_INLINE static inline __attribute__((always_inline))

#define A0_STATIC_INLINE_RECURSIVE static inline

#endif  // A0_INLINE_H
