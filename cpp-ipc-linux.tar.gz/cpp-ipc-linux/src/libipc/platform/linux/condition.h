#pragma once

#include <cstdio>
#include <cinttypes>
#include <cstring>
#include "libipc/mutex.h"

#include "get_wait_time.h"
#include "sync_obj_impl.h"

#include "a0/err_macro.h"
#include "a0/mtx.h"

namespace ipc {
namespace detail {
namespace sync {

class condition : public sync::obj_impl<a0_cnd_t> {
public:
    condition() = default;
    ~condition() = default;

    bool wait(ipc::sync::mutex &mtx, std::uint64_t tm) noexcept {
        if (!valid()) return false;
        if (tm == invalid_value) {
            int eno = A0_SYSERR(a0_cnd_wait(native(), static_cast<a0_mtx_t *>(mtx.native())));
            if (eno != 0) {
                std::fprintf(stderr, "fail condition wait[%d]: %s\n", eno, std::strerror(eno));
                return false;
            }
        } else {
            auto ts = detail::make_timespec(tm);
            int eno = A0_SYSERR(a0_cnd_timedwait(native(), static_cast<a0_mtx_t *>(mtx.native()), {ts}));
            if (eno != 0) {
                if (eno != ETIMEDOUT) {
                    std::fprintf(stderr, "fail condition timedwait[%d]: %s, tm = %" PRIu64 ", tv = %ld.%ld\n",
                                eno, std::strerror(eno), static_cast<std::uint64_t>(tm), ts.tv_sec, ts.tv_nsec);
                }
                return false;
            }
        }
        return true;
    }

    bool notify(ipc::sync::mutex &mtx) noexcept {
        if (!valid()) return false;
        int eno = A0_SYSERR(a0_cnd_signal(native(), static_cast<a0_mtx_t *>(mtx.native())));
        if (eno != 0) {
            std::fprintf(stderr, "fail condition notify[%d]: %s\n", eno, std::strerror(eno));
            return false;
        }
        return true;
    }

    bool broadcast(ipc::sync::mutex &mtx) noexcept {
        if (!valid()) return false;
        int eno = A0_SYSERR(a0_cnd_broadcast(native(), static_cast<a0_mtx_t *>(mtx.native())));
        if (eno != 0) {
            std::fprintf(stderr, "fail condition broadcast[%d]: %s\n", eno, std::strerror(eno));
            return false;
        }
        return true;
    }
};

} // namespace sync
} // namespace detail
} // namespace ipc
