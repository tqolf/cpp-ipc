
#include "libipc/platform/posix/shm_posix.cpp"
