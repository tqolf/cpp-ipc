#pragma once

#include <new>
#include <utility>

#include <type_traits>
#include "libipc/pool_alloc.h"

namespace ipc {

// pimpl small object optimization helpers

template <typename T>
inline constexpr bool __ipc_pimpl_small__ = (sizeof(T) <= sizeof(T*));

template <typename T, typename... P>
constexpr T* make_impl(P&&... params) {
    if constexpr (__ipc_pimpl_small__<T>) {
        T* buf {};
        ::new (&buf) T { std::forward<P>(params)... };
        return buf;
    } else {
        return mem::alloc<T>(std::forward<P>(params)...);
    }
}

template <typename T>
constexpr T* impl(T* const (& p)) {
    if constexpr (__ipc_pimpl_small__<T>) {
        return reinterpret_cast<T*>(&const_cast<char &>(reinterpret_cast<char const &>(p)));
    } else {
        return p;
    }
}

template <typename T>
constexpr void clear_impl(T* p) {
    if constexpr (__ipc_pimpl_small__<T>) {
        if (p != nullptr) impl(p)->~T();
    } else {
        mem::free(p);
    }
}

template <typename T>
struct pimpl {
    template <typename... P>
    constexpr static T* make(P&&... params) {
        return make_impl<T>(std::forward<P>(params)...);
    }

    constexpr void clear() {
        clear_impl(static_cast<T*>(const_cast<pimpl*>(this)));
    }
};
} // namespace ipc
